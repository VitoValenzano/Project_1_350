--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.13 (Ubuntu 14.13-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 16.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Project 1";
--
-- Name: Project 1; Type: DATABASE; Schema: -; Owner: alex
--

CREATE DATABASE "Project 1" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


ALTER DATABASE "Project 1" OWNER TO alex;

\connect -reuse-previous=on "dbname='Project 1'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: patients; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public.patients (
    patient_id integer NOT NULL,
    age real,
    age_units character varying(10),
    sex text,
    report_id character varying(25)
);


ALTER TABLE public.patients OWNER TO alex;

--
-- Name: reports; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public.reports (
    report_id character varying(25) NOT NULL,
    date_received character varying(10),
    date_event character varying(10),
    case_outcome character varying(100),
    patient_id integer
);


ALTER TABLE public.reports OWNER TO alex;

--
-- Name: symptoms; Type: TABLE; Schema: public; Owner: alex
--

CREATE TABLE public.symptoms (
    meddra_term text,
    report_id character varying(25) NOT NULL,
    symptom_id integer NOT NULL
);


ALTER TABLE public.symptoms OWNER TO alex;

--
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public.patients (patient_id, age, age_units, sex, report_id) FROM stdin;
\.
COPY public.patients (patient_id, age, age_units, sex, report_id) FROM '$$PATH$$/3326.dat';

--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public.reports (report_id, date_received, date_event, case_outcome, patient_id) FROM stdin;
\.
COPY public.reports (report_id, date_received, date_event, case_outcome, patient_id) FROM '$$PATH$$/3325.dat';

--
-- Data for Name: symptoms; Type: TABLE DATA; Schema: public; Owner: alex
--

COPY public.symptoms (meddra_term, report_id, symptom_id) FROM stdin;
\.
COPY public.symptoms (meddra_term, report_id, symptom_id) FROM '$$PATH$$/3324.dat';

--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (patient_id);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (report_id);


--
-- Name: symptoms symptoms_pkey; Type: CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public.symptoms
    ADD CONSTRAINT symptoms_pkey PRIMARY KEY (symptom_id);


--
-- Name: reports fk_patients; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT fk_patients FOREIGN KEY (patient_id) REFERENCES public.patients(patient_id);


--
-- Name: patients fk_reports_p; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT fk_reports_p FOREIGN KEY (report_id) REFERENCES public.reports(report_id);


--
-- Name: symptoms fk_reports_s; Type: FK CONSTRAINT; Schema: public; Owner: alex
--

ALTER TABLE ONLY public.symptoms
    ADD CONSTRAINT fk_reports_s FOREIGN KEY (report_id) REFERENCES public.reports(report_id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

